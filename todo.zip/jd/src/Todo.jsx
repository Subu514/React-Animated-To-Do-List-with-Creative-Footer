import React, { useState } from 'react';
import "./Todo.css"; // <--- Add this CSS file

function Todo() {
  const [todo, setodo] = useState('');
  const [task, setask] = useState([]);

  const formhandler = (e) => {
    e.preventDefault();

    if (todo) {
      setask([...task, { text: todo, com: false }]);
      setodo('');
    }
  };

  const completehandler = (index) => {
    const newtodo = [...task];
    newtodo[index].com = !newtodo[index].com;
    setask(newtodo);
  };

  const deletehandler = (index) => {
    const newtodo = [...task];
    newtodo.splice(index, 1);
    setask(newtodo);
  };

  return (
    <>
      <div className="todo-container">
        <h1 className="title">✨ To-Do List ✨</h1>

        <form onSubmit={formhandler} className="todo-form">
          <input
            type="text"
            value={todo}
            onChange={(e) => setodo(e.target.value)}
            placeholder="Add a task..."
            className="todo-input"
          />
          <button type="submit" className="add-btn">Add</button>
        </form>

        <ul className="todo-list">
          {task.map((todo, i) => (
            <li key={i} className="todo-item">
              <span
                className={todo.com ? "completed" : ""}
              >
                {todo.text}
              </span>

              <div className="btn-group">
                <button onClick={() => completehandler(i)} className="complete-btn">
                  ✔
                </button>

                <button onClick={() => deletehandler(i)} className="delete-btn">
                  ✖
                </button>
              </div>
            </li>
          ))}
        </ul>
      </div>

 {/* ------------ Footer -------------- */}
        <footer class="footer">
 
    <div class="footer-about">
      <h2>Subu</h2>
      <p>Your one-stop destination for quality content and creative solutions.</p>
    </div>

    

  <div class="footer-bottom">
    <p>© 2025 Subu. All rights reserved.</p>
  </div>
</footer>
        </>       
    )
}
export default Todo

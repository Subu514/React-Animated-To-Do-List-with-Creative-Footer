// import "./App.css"
// import { useState } from "react"


// function App() {
 
// const [todo,setodo] = useState("")
// const [todos,setodos]=useState([])

// const formhadler = (e) =>{
//   e.preventDefault();
//   if(todo){
//     setodos([...todos,{text:todo,com:false}]) // array object 
//     setodo("")
//  }
// }


// const completehandler = (index) =>{
//   const newTodos = [...todos];
//   newTodos[index].com = !newTodos[index].com
//   setodos(newTodos)
// }


// const deletehandler = (index) =>{

//  const newTodos = [...todos];  // create copy
//   newTodos.splice(index, 1);    // remove 1 item at this index
//   setodos(newTodos);            // update the state
// }
 
//   return (
//     <>
    
//     <h1>Todo List</h1>
//     <form onSubmit={formhadler}>
//       <input 
//       type="text"
//      placeholder="Add to task...?" 
//      value={todo}
//      onChange={(e)=>setodo(e.target.value)}

//       />
//       <button type="submit"> Add</button>
//     </form>

//     <ul>
//       {/* map :- it is a array method use as loop to access multiple values in array  */}
//       {todos.map((todo,i)=>(
//         <li key={i}>
//             <span 
//             style={{textDecoration:todo.com ? "line-through " : " none"}}>{todo.text}
//              </span>
//            <button onClick={() => completehandler(i)}>complated</button>
//            <button onClick={() => deletehandler(i)}>DELETE</button>

//         </li>
//       ))}
//     </ul>
//     </>
//   )
// }

// export default App

import React from 'react'
import Todo from './Todo'

function App() {
  return (
    <>
    <Todo/>
    </>
      
    
  )
}

export default App

